//
//  SettingsView.swift
//  OneNews
//
//  Created by George Hitchman-Smith on 27/05/2025.
//


import OneSignalFramework
import SwiftUI

struct SettingsView: View {
    @State private var appId: String = UserDefaults.standard.string(forKey: "OneSignalAppId") ?? ""
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("OneSignal App ID")) {
                    HStack {
                        TextField("Enter OneSignal App ID", text: $appId)
                            .autocapitalization(.none)
                            .disableAutocorrection(true)
                        
                        Button("Paste") {
                            if let pasteboard = UIPasteboard.general.string {
                                appId = pasteboard
                            }
                        }
                    }
                }

                Button("Save App ID") {
                    UserDefaults.standard.set(appId, forKey: "OneSignalAppId")
                    OneSignal.initialize(appId)
                    presentationMode.wrappedValue.dismiss()
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
